import type { PoseLandmarks as PoseLandmarksSpec } from './specs/pose-landmarks.nitro';
export declare const PoseLandmarks: PoseLandmarksSpec;
//# sourceMappingURL=index.d.ts.map